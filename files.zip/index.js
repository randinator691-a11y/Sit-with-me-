// Server-side threat check. Runs on every new message, so it can't be bypassed from the browser.
// Requires the Firebase Blaze (pay-as-you-go) plan; typical small-site cost is near zero.
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

const THREAT_PATTERNS = [
  /\b(kill|murder|stab|shoot|strangle|rape|hurt|beat up|find|come for) (you|ya|u)\b/,
  /\b(i|im|ill|i will|i ll|gonna|going to|ima) \w*\s?\w*\s?(kill|murder|stab|shoot|strangle|rape|beat up) (them|her|him|everyone|people)\b/,
  /\bi know where you (live|are|stay)\b/,
  /\b(you|u) (should|deserve to|better) (die|be dead|kill yourself)\b/,
  /\bkill yourself\b|\bkys\b/,
  /\b(i will|ill|gonna|going to) (bomb|shoot up|burn down)\b/
];
const norm = s => s.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();

exports.screenMessage = onDocumentCreated('chats/{chatId}/messages/{msgId}', async (event) => {
  const msg = event.data.data();
  const n = norm(msg.text || '');
  if (!THREAT_PATTERNS.some(r => r.test(n))) return;

  const batch = db.batch();
  batch.delete(event.data.ref);                                                    // remove the message
  batch.set(db.collection('bans').doc(msg.uid), { reason: 'auto-threat', source: 'server', t: admin.firestore.FieldValue.serverTimestamp() });
  batch.set(db.collection('reports').doc(), { chatId: event.params.chatId, uid: msg.uid, reason: 'auto-threat', text: msg.text, source: 'server', t: admin.firestore.FieldValue.serverTimestamp() });
  batch.update(db.collection('chats').doc(event.params.chatId), { active: false, endedBy: 'ban:' + msg.uid });
  await batch.commit();
});
